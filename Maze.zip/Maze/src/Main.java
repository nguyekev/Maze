public class Main {
    public static void main(String[] args) {
        Maze maze = new Maze(5, 5);
        System.out.println(maze);
    }
}
